package com.example.lab2

class President(val name: String, val start: Int, val finish: Int, val desc: String) {

}
